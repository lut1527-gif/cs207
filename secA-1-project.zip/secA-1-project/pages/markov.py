import pandas as pd
import streamlit as st

from services.data_service import load_datasets
from services.text_prediction import build_model, generate_text, predict_next, transition_matrix

st.title("🔗 ทำนายคำด้วย Markov Chain")

datasets = load_datasets()
CUSTOM = "ใช้ข้อความของฉันเอง"
choice = st.selectbox("ชุดข้อมูล", [d["name"] for d in datasets] + [CUSTOM])
default_context = ""
if choice == CUSTOM:
    corpus = st.text_area("ข้อความสำหรับสร้างโมเดล (คั่นคำด้วยช่องว่าง)", height=120)
else:
    selected = next(d for d in datasets if d["name"] == choice)
    corpus = selected["text"]
    default_context = selected.get("default_context", "")
    with st.expander("ดูข้อความต้นฉบับ"):
        st.write(corpus)

c1, c2 = st.columns(2)
order = c1.radio("Order ของโมเดล", [1, 2], horizontal=True, help="จำนวนคำก่อนหน้าที่ใช้ทำนาย")
top_k = c2.slider("จำนวนคำที่ทำนาย", 1, 10, 5)

context = st.text_input("ข้อความเริ่มต้น", value=default_context, key=f"ctx_{choice}")

try:
    model = build_model(corpus, order)
    preds = predict_next(model, context, top_k)
except ValueError as e:
    st.error(str(e))
    st.stop()

m = st.columns(2)
m[0].metric("จำนวนคำทั้งหมด", model["token_count"])
m[1].metric("คำไม่ซ้ำ", model["vocab_size"])

st.subheader("คำที่น่าจะตามมา")
if preds:
    df = pd.DataFrame(preds, columns=["คำ", "ความน่าจะเป็น"])
    left, right = st.columns(2)
    left.dataframe(df, hide_index=True)
    right.bar_chart(df.set_index("คำ"))
else:
    st.warning("ไม่พบข้อความนี้ในชุดข้อมูล ลองใช้คำอื่นที่อยู่ในข้อความต้นฉบับ")

st.subheader("สร้างประโยคต่อ")
g1, g2 = st.columns(2)
length = g1.slider("จำนวนคำที่สร้าง", 3, 40, 15)
seed = g2.number_input("Seed (0 = สุ่มใหม่ทุกครั้ง)", min_value=0, value=0, step=1)
if st.button("สร้างประโยค", type="primary"):
    try:
        st.success(generate_text(model, context, length, seed or None))
    except ValueError as e:
        st.error(str(e))

if order == 1:
    st.subheader("Transition Probability Matrix")
    st.caption("แถวคือคำปัจจุบัน คอลัมน์คือคำถัดไป (แสดง 12 คำที่พบบ่อยที่สุด)")
    tm = transition_matrix(model)
    st.dataframe(pd.DataFrame(tm["matrix"], index=tm["states"], columns=tm["states"]).round(2))
