import streamlit as st

from services.data_service import load_members

st.title("👥 สมาชิกในกลุ่ม")

members = load_members()
cols = st.columns(min(len(members), 4) or 1)
for i, mem in enumerate(members):
    with cols[i % len(cols)].container(border=True):
        if mem["image_path"]:
            st.image(mem["image_path"])
        else:
            st.warning("ไม่พบรูปภาพ")
        st.subheader(mem["name"])
        st.write(f"รหัสนักศึกษา: {mem['student_id']}")
        st.write(f"หน้าที่: {mem['role']}")
