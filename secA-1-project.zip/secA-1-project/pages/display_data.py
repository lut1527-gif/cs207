import pandas as pd
import streamlit as st

from services.data_service import list_data_files, load_json, summarize_datasets

st.title("🗂️ ดูข้อมูลดิบ")

tab1, tab2 = st.tabs(["สรุปชุดข้อมูล", "เปิดไฟล์ JSON"])

with tab1:
    st.dataframe(pd.DataFrame(summarize_datasets()), hide_index=True)

with tab2:
    filename = st.selectbox("เลือกไฟล์ในโฟลเดอร์ data/", list_data_files())
    try:
        content = load_json(filename)
    except (FileNotFoundError, ValueError) as e:
        st.error(str(e))
        st.stop()
    view = st.radio("รูปแบบ", ["JSON", "ตาราง"], horizontal=True)
    if view == "JSON":
        st.json(content)
    else:
        rows = content.get("datasets") if isinstance(content, dict) else content
        if isinstance(rows, list) and rows and isinstance(rows[0], dict):
            st.dataframe(pd.DataFrame(rows), hide_index=True)
        else:
            st.info("ไฟล์นี้แสดงเป็นตารางไม่ได้ ใช้มุมมอง JSON แทน")
