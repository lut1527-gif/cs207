import streamlit as st

st.title("Probability & Applied Math Lab")
st.write("เครื่องมือคำนวณสถิติ ความน่าจะเป็น Markov Chain และ Sigmoid/Softmax ในที่เดียว")

apps = [
    ("pages/statistics.py", "📊 สถิติพื้นฐาน", "กรอกชุดตัวเลข แล้วดู Mean, Median, Mode, SD และ Variance"),
    ("pages/bayes.py", "🎲 ทฤษฎีบทของเบย์ส", "อัปเดตความน่าจะเป็นจาก Prior, Likelihood และ Evidence"),
    ("pages/markov.py", "🔗 Markov Chain", "ทำนายคำถัดไปและสร้างประโยคจากข้อความตัวอย่าง"),
    ("pages/display_data.py", "🗂️ ดูข้อมูลดิบ", "เปิดดูไฟล์ JSON ในโฟลเดอร์ data/"),
    ("pages/custom_app.py", "🧪 Sigmoid / Softmax Explorer", "ทดลองฟังก์ชัน Sigmoid, Softmax, Cross-entropy และฝึก Logistic Regression"),
    ("pages/members.py", "👥 สมาชิกในกลุ่ม", "รายชื่อและหน้าที่ความรับผิดชอบ"),
]

cols = st.columns(3)
for i, (path, title, desc) in enumerate(apps):
    with cols[i % 3].container(border=True):
        st.subheader(title)
        st.caption(desc)
        st.page_link(path, label="เปิดหน้านี้")

st.divider()
st.subheader("โครงสร้างระบบ")
st.table(
    {
        "หน้า (pages/)": ["statistics.py", "bayes.py", "markov.py", "display_data.py", "custom_app.py", "members.py"],
        "บริการคำนวณ (services/)": [
            "cal_statistics.py, cal_mode.py",
            "bayes_service.py",
            "text_prediction.py",
            "data_service.py",
            "custom_service.py",
            "data_service.py",
        ],
        "หลักการ": [
            "สถิติเชิงพรรณนา",
            "Bayes' Theorem",
            "Markov Chain / Transition Matrix",
            "อ่านไฟล์ JSON",
            "แคลคูลัส (อนุพันธ์ Sigmoid) และ Gradient Descent",
            "แสดงข้อมูลสมาชิก",
        ],
    }
)
