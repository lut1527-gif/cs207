import pandas as pd
import streamlit as st

from services.bayes_service import calculate_bayes, posterior_curve

st.title("🎲 ทฤษฎีบทของเบย์ส")
st.latex(r"P(A\mid B)=\frac{P(B\mid A)\,P(A)}{P(B)}")

mode = st.radio(
    "วิธีระบุ Evidence",
    ["กรอก P(B) โดยตรง", "คำนวณ P(B) จาก P(B|A) และ P(B|ไม่ใช่ A)"],
    horizontal=True,
)

c1, c2, c3 = st.columns(3)
prior = c1.number_input("Prior P(A)", 0.0, 1.0, 0.01, step=0.01, format="%.4f")
likelihood = c2.number_input("Likelihood P(B|A)", 0.0, 1.0, 0.95, step=0.01, format="%.4f")

evidence = None
fp = None
if mode.startswith("กรอก"):
    evidence = c3.number_input("Evidence P(B)", 0.0, 1.0, 0.059, step=0.001, format="%.4f")
else:
    fp = c3.number_input("P(B|ไม่ใช่ A)", 0.0, 1.0, 0.05, step=0.01, format="%.4f")

try:
    r = calculate_bayes(prior, likelihood, evidence=evidence, likelihood_not_a=fp)
except ValueError as e:
    st.error(str(e))
    st.stop()

m = st.columns(3)
m[0].metric("Posterior P(A|B)", f"{r['posterior']:.4%}")
m[1].metric("Prior P(A)", f"{r['prior']:.4%}")
m[2].metric("Evidence P(B)", f"{r['evidence']:.4%}")

st.info(
    f"หลังพบ B ความน่าจะเป็นของ A เปลี่ยนจาก {r['prior']:.2%} เป็น {r['posterior']:.2%} "
    f"(เปลี่ยนไป {r['lift']:.2f} เท่า)"
)

st.subheader("เปรียบเทียบ Prior กับ Posterior")
st.bar_chart(pd.DataFrame({"ความน่าจะเป็น": [r["prior"], r["posterior"]]}, index=["Prior", "Posterior"]))

if fp is not None:
    st.subheader("Posterior เปลี่ยนตาม Prior อย่างไร")
    curve = posterior_curve(likelihood, fp)
    st.line_chart(pd.DataFrame({"Posterior": curve["posterior"]}, index=curve["prior"]))
