import pandas as pd
import streamlit as st

from services import custom_service as svc

st.title("🧪 Sigmoid / Softmax Explorer")
st.caption("ทดลองฟังก์ชันที่ใช้ใน Machine Learning พร้อมดูอนุพันธ์และการเรียนรู้ด้วย Gradient Descent")

tab1, tab2, tab3, tab4 = st.tabs(["Sigmoid", "Softmax", "Cross-entropy", "Logistic Regression"])

# ---------------- Sigmoid ----------------
with tab1:
    st.latex(r"\sigma(wx+b)=\frac{1}{1+e^{-(wx+b)}},\qquad \frac{d\sigma}{dx}=w\,\sigma(1-\sigma)")
    c = st.columns(4)
    w = c[0].slider("w (ความชัน)", -10.0, 10.0, 1.0, 0.1)
    b = c[1].slider("b (ค่าเลื่อน)", -10.0, 10.0, 0.0, 0.1)
    x_min = c[2].number_input("x ต่ำสุด", value=-10.0)
    x_max = c[3].number_input("x สูงสุด", value=10.0)
    try:
        curve = svc.sigmoid_curve(w, b, x_min, x_max)
    except ValueError as e:
        st.error(str(e))
    else:
        st.line_chart(
            pd.DataFrame({"σ(x)": curve["sigmoid"], "dσ/dx": curve["derivative"]}, index=curve["x"])
        )
        x0 = st.number_input("ทดลองค่า x", value=1.0)
        v = svc.sigmoid_value(x0, w, b)
        m = st.columns(3)
        m[0].metric("z = wx + b", f"{v['z']:.4f}")
        m[1].metric("σ(z)", f"{v['sigmoid']:.6f}")
        m[2].metric("dσ/dx", f"{v['derivative']:.6f}")

# ---------------- Softmax ----------------
with tab2:
    st.latex(r"\mathrm{softmax}(z_i)=\frac{e^{z_i/T}}{\sum_j e^{z_j/T}}")
    logits = st.text_input("Logits", "2.0, 1.0, 0.1", key="sm_logits")
    labels = st.text_input("ชื่อคลาส (ไม่บังคับ คั่นด้วยจุลภาค)", "แมว, หมา, นก", key="sm_labels")
    temp = st.slider("Temperature (T)", 0.1, 5.0, 1.0, 0.1)
    try:
        sm = svc.softmax_analysis(logits, labels, temp)
        sweep = svc.temperature_sweep(logits)
    except ValueError as e:
        st.error(str(e))
    else:
        m = st.columns(3)
        m[0].metric("คลาสที่มั่นใจที่สุด", sm["top_label"])
        m[1].metric("ความน่าจะเป็น", f"{sm['top_probability']:.2%}")
        m[2].metric("Entropy", f"{sm['entropy']:.4f}", help=f"สูงสุดที่เป็นไปได้ = {sm['max_entropy']:.4f}")
        st.bar_chart(pd.DataFrame({"P": sm["probabilities"]}, index=sm["labels"]))
        st.subheader("ผลของ Temperature")
        st.dataframe(
            pd.DataFrame(sweep, index=sm["labels"]).rename(columns=lambda t: f"T={t}").round(4),
            
        )
        st.caption("T ต่ำ: คำตอบแหลมคม / T สูง: กระจายเกือบเท่ากัน")

# ---------------- Cross-entropy ----------------
with tab3:
    st.latex(r"L=-\log p_{y},\qquad \frac{\partial L}{\partial z_i}=p_i-\mathbb{1}[i=y]")
    logits3 = st.text_input("Logits", "2.0, 1.0, 0.1", key="ce_logits")
    labels3 = st.text_input("ชื่อคลาส", "แมว, หมา, นก", key="ce_labels")
    names = [t.strip() for t in labels3.split(",") if t.strip()] or ["class 1", "class 2", "class 3"]
    true_name = st.selectbox("คลาสที่ถูกต้อง", names)
    try:
        ce = svc.cross_entropy_analysis(logits3, labels3, names.index(true_name))
    except ValueError as e:
        st.error(str(e))
    else:
        m = st.columns(3)
        m[0].metric("Loss", f"{ce['loss']:.4f}")
        m[1].metric("โมเดลทำนาย", ce["predicted"])
        m[2].metric("ทำนายถูก", "ใช่" if ce["correct"] else "ไม่")
        st.dataframe(
            pd.DataFrame(
                {"ความน่าจะเป็น": ce["probabilities"], "Gradient (p - y)": ce["gradient"]},
                index=ce["labels"],
            ).round(4),
            
        )

# ---------------- Logistic regression ----------------
with tab4:
    st.write("ฝึกโมเดล p(y=1|x) = σ(wx+b) ด้วย Gradient Descent จากข้อมูลที่กรอกเอง")
    points = st.text_area(
        "ข้อมูล (บรรทัดละ x,y โดย y เป็น 0 หรือ 1) เช่น ชั่วโมงอ่านหนังสือ, สอบผ่านหรือไม่",
        "1,0\n2,0\n3,0\n4,0\n4.5,0\n5.5,1\n6,1\n7,1\n8,1\n9,1",
        height=180,
    )
    c = st.columns(2)
    lr = c[0].select_slider("Learning rate", [0.01, 0.03, 0.1, 0.3, 1.0], value=0.1)
    epochs = c[1].slider("Epochs", 50, 5000, 1000, 50)
    try:
        xs, ys = svc.parse_points(points)
        fit = svc.train_logistic(xs, ys, lr, epochs)
    except ValueError as e:
        st.error(str(e))
    else:
        m = st.columns(4)
        m[0].metric("w", f"{fit['w']:.4f}")
        m[1].metric("b", f"{fit['b']:.4f}")
        m[2].metric("Loss สุดท้าย", f"{fit['final_loss']:.4f}")
        m[3].metric("Accuracy", f"{fit['accuracy']:.0%}")
        if fit["boundary"] is not None:
            st.info(f"เส้นแบ่งการตัดสินใจ (p = 0.5) อยู่ที่ x ≈ {fit['boundary']:.3f}")
        left, right = st.columns(2)
        left.subheader("Loss ลดลงตาม Epoch")
        left.line_chart(pd.DataFrame({"loss": fit["loss_history"]}))
        right.subheader("เส้นโค้งที่เรียนรู้ได้")
        right.line_chart(pd.DataFrame({"p(y=1|x)": fit["curve"]}, index=fit["grid"]))
        x_new = st.number_input("ทำนายค่า x ใหม่", value=5.0)
        pr = svc.predict_logistic(fit["w"], fit["b"], x_new)
        st.metric("p(y=1)", f"{pr['probability']:.2%}", delta="ผ่าน (1)" if pr["label"] else "ไม่ผ่าน (0)")
