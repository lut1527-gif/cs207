import pandas as pd
import streamlit as st

from services.cal_statistics import parse_numbers, summarize

st.title("📊 สถิติพื้นฐาน")
st.caption("คั่นตัวเลขด้วยจุลภาค ช่องว่าง หรือขึ้นบรรทัดใหม่")

raw = st.text_area("ชุดตัวเลข", value="-100, 0, 10, 20, 30, 100", height=100)
kind = st.radio("ประเภทข้อมูล", ["Population (หารด้วย N)", "Sample (หารด้วย N-1)"], horizontal=True)

try:
    result = summarize(parse_numbers(raw), sample=kind.startswith("Sample"))
except ValueError as e:
    st.error(str(e))
    st.stop()

mode_text = ", ".join(f"{m:g}" for m in result["mode"]) if result["mode"] else "ไม่มี"

c = st.columns(5)
c[0].metric("Mean", f"{result['mean']:.4f}")
c[1].metric("Median", f"{result['median']:.4f}")
c[2].metric("Mode", mode_text)
c[3].metric("SD", f"{result['sd']:.4f}")
c[4].metric("Variance", f"{result['variance']:.4f}")

c = st.columns(5)
c[0].metric("จำนวนข้อมูล", result["count"])
c[1].metric("ผลรวม", f"{result['sum']:g}")
c[2].metric("ต่ำสุด", f"{result['min']:g}")
c[3].metric("สูงสุด", f"{result['max']:g}")
c[4].metric("พิสัย", f"{result['range']:g}")

left, right = st.columns(2)
with left:
    st.subheader("ข้อมูลเรียงลำดับ")
    st.bar_chart(pd.DataFrame({"ค่า": result["sorted"]}))
with right:
    st.subheader("ตารางความถี่")
    st.dataframe(
        pd.DataFrame(result["frequency"], columns=["ค่า", "ความถี่"]),
        hide_index=True,
        
    )
