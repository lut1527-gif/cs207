"""Entry point: page routing only."""
import streamlit as st

st.set_page_config(page_title="Probability & Applied Math Lab", page_icon="📐", layout="wide")

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700&display=swap');
    html, body, [class*="css"] { font-family: 'Sarabun', sans-serif; }
    h1, h2, h3 { font-weight: 700; letter-spacing: -0.01em; }
    </style>
    """,
    unsafe_allow_html=True,
)

pages = [
    st.Page("pages/home.py", title="หน้าแรก", icon="🏠", default=True),
    st.Page("pages/statistics.py", title="สถิติพื้นฐาน", icon="📊"),
    st.Page("pages/bayes.py", title="ทฤษฎีบทของเบย์ส", icon="🎲"),
    st.Page("pages/markov.py", title="ทำนายคำด้วย Markov Chain", icon="🔗"),
    st.Page("pages/display_data.py", title="ดูข้อมูลดิบ", icon="🗂️"),
    st.Page("pages/custom_app.py", title="Sigmoid / Softmax Explorer", icon="🧪"),
    st.Page("pages/members.py", title="สมาชิกในกลุ่ม", icon="👥"),
]

st.navigation(pages).run()
