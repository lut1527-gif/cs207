"""Read files in data/ (JSON, images). No UI code here."""
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
IMG_DIR = DATA_DIR / "imgs"


def list_data_files():
    return sorted(p.name for p in DATA_DIR.glob("*.json"))


def load_json(filename):
    path = DATA_DIR / filename
    if not path.is_file():
        raise FileNotFoundError(f"ไม่พบไฟล์ data/{filename}")
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def load_datasets():
    return load_json("raw_data.json")["datasets"]


def load_members():
    members = load_json("members.json")
    for m in members:
        path = IMG_DIR / m.get("image", "")
        m["image_path"] = str(path) if path.is_file() else None
    return members


def summarize_datasets():
    rows = []
    for d in load_datasets():
        words = d["text"].split()
        rows.append(
            {
                "id": d["id"],
                "ชื่อชุดข้อมูล": d["name"],
                "ภาษา": d["language"],
                "จำนวนคำ": len(words),
                "คำไม่ซ้ำ": len({w.lower() for w in words}),
            }
        )
    return rows
