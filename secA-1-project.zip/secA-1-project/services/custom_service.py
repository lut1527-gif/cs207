"""Sigmoid / Softmax Explorer: activation functions, derivatives, loss, training."""
import math

import numpy as np

from services.cal_statistics import parse_numbers


# ---------- Sigmoid ----------
def sigmoid(z):
    """Numerically stable sigmoid."""
    z = np.asarray(z, dtype=float)
    e = np.exp(-np.abs(z))
    return np.where(z >= 0, 1 / (1 + e), e / (1 + e))


def sigmoid_value(x, w=1.0, b=0.0):
    z = w * x + b
    s = float(sigmoid(z))
    return {"z": z, "sigmoid": s, "derivative": w * s * (1 - s)}


def sigmoid_curve(w=1.0, b=0.0, x_min=-10.0, x_max=10.0, points=201):
    if x_min >= x_max:
        raise ValueError("x ต่ำสุดต้องน้อยกว่า x สูงสุด")
    x = np.linspace(x_min, x_max, points)
    s = sigmoid(w * x + b)
    return {
        "x": x.tolist(),
        "sigmoid": s.tolist(),
        "derivative": (w * s * (1 - s)).tolist(),
    }


# ---------- Softmax ----------
def softmax(logits, temperature=1.0):
    if temperature <= 0:
        raise ValueError("Temperature ต้องมากกว่า 0")
    z = np.asarray(logits, dtype=float) / temperature
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()


def _parse_labels(labels_text, n):
    labels = [t.strip() for t in (labels_text or "").split(",") if t.strip()]
    if not labels:
        return [f"class {i + 1}" for i in range(n)]
    if len(labels) != n:
        raise ValueError(f"จำนวนชื่อคลาส ({len(labels)}) ไม่เท่ากับจำนวน logits ({n})")
    return labels


def softmax_analysis(logits_text, labels_text="", temperature=1.0):
    logits = parse_numbers(logits_text)
    if len(logits) < 2:
        raise ValueError("Softmax ต้องมี logits อย่างน้อย 2 ค่า")
    labels = _parse_labels(labels_text, len(logits))
    p = softmax(logits, temperature)
    entropy = float(-(p * np.log(np.clip(p, 1e-12, None))).sum())
    return {
        "logits": logits,
        "labels": labels,
        "probabilities": p.tolist(),
        "entropy": entropy,
        "max_entropy": math.log(len(logits)),
        "top_label": labels[int(p.argmax())],
        "top_probability": float(p.max()),
    }


def temperature_sweep(logits_text, temperatures=(0.1, 0.5, 1.0, 2.0, 5.0)):
    logits = parse_numbers(logits_text)
    return {t: softmax(logits, t).tolist() for t in temperatures}


# ---------- Cross-entropy ----------
def cross_entropy_analysis(logits_text, labels_text, true_index, temperature=1.0):
    logits = parse_numbers(logits_text)
    n = len(logits)
    if n < 2:
        raise ValueError("ต้องมี logits อย่างน้อย 2 ค่า")
    if not 0 <= true_index < n:
        raise ValueError("คลาสที่ถูกต้องอยู่นอกช่วง")
    labels = _parse_labels(labels_text, n)
    p = softmax(logits, temperature)
    loss = float(-np.log(max(p[true_index], 1e-12)))
    one_hot = np.zeros(n)
    one_hot[true_index] = 1.0
    gradient = (p - one_hot) / temperature  # dLoss/dlogits
    return {
        "labels": labels,
        "probabilities": p.tolist(),
        "loss": loss,
        "gradient": gradient.tolist(),
        "predicted": labels[int(p.argmax())],
        "correct": int(p.argmax()) == true_index,
    }


# ---------- Logistic regression via gradient descent ----------
def parse_points(text):
    """Parse lines 'x,y' with y in {0,1}."""
    xs, ys = [], []
    for line_no, line in enumerate((text or "").strip().splitlines(), 1):
        if not line.strip():
            continue
        parts = [p for p in line.replace(";", ",").split(",") if p.strip()]
        if len(parts) != 2:
            raise ValueError(f"บรรทัดที่ {line_no}: ต้องเป็นรูปแบบ x,y")
        x, y = parse_numbers(",".join(parts))
        if y not in (0.0, 1.0):
            raise ValueError(f"บรรทัดที่ {line_no}: y ต้องเป็น 0 หรือ 1")
        xs.append(x)
        ys.append(y)
    if len(xs) < 2 or len(set(ys)) < 2:
        raise ValueError("ต้องมีข้อมูลอย่างน้อย 2 จุด และมีทั้งคลาส 0 และ 1")
    return xs, ys


def train_logistic(xs, ys, lr=0.1, epochs=500):
    """Fit p(y=1|x) = sigmoid(w*x + b) by batch gradient descent."""
    if not 0 < lr <= 10:
        raise ValueError("Learning rate ต้องอยู่ในช่วง (0, 10]")
    if not 1 <= epochs <= 20000:
        raise ValueError("Epochs ต้องอยู่ในช่วง 1–20000")
    x = np.asarray(xs, dtype=float)
    y = np.asarray(ys, dtype=float)
    w, b = 0.0, 0.0
    history = []
    for _ in range(int(epochs)):
        p = sigmoid(w * x + b)
        loss = float(-np.mean(y * np.log(np.clip(p, 1e-12, None))
                              + (1 - y) * np.log(np.clip(1 - p, 1e-12, None))))
        history.append(loss)
        w -= lr * float(np.mean((p - y) * x))   # dL/dw
        b -= lr * float(np.mean(p - y))         # dL/db
    p = sigmoid(w * x + b)
    accuracy = float(np.mean((p >= 0.5) == (y == 1)))
    pad = max((x.max() - x.min()) * 0.15, 0.5)
    grid = np.linspace(x.min() - pad, x.max() + pad, 100)
    return {
        "w": w,
        "b": b,
        "loss_history": history,
        "final_loss": history[-1],
        "accuracy": accuracy,
        "boundary": (-b / w) if abs(w) > 1e-12 else None,
        "grid": grid.tolist(),
        "curve": sigmoid(w * grid + b).tolist(),
    }


def predict_logistic(w, b, x):
    p = float(sigmoid(w * x + b))
    return {"probability": p, "label": int(p >= 0.5)}
