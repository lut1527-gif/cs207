"""Markov-chain next-word prediction (order 1 or 2)."""
import random
import re
from collections import Counter, defaultdict


def tokenize(text):
    """Split on whitespace; punctuation . ! ? , become their own tokens.

    Thai text in raw_data.json is stored pre-segmented with spaces.
    """
    spaced = re.sub(r"([.!?,])", r" \1 ", text or "")
    return spaced.lower().split()


def build_model(text, order=1):
    if order not in (1, 2):
        raise ValueError("order ต้องเป็น 1 หรือ 2")
    tokens = tokenize(text)
    if len(tokens) <= order:
        raise ValueError("ข้อความสั้นเกินไปสำหรับสร้างโมเดล")
    transitions = defaultdict(Counter)
    for i in range(len(tokens) - order):
        state = " ".join(tokens[i : i + order])
        transitions[state][tokens[i + order]] += 1
    return {
        "order": order,
        "transitions": {s: dict(c) for s, c in transitions.items()},
        "vocab_size": len(set(tokens)),
        "token_count": len(tokens),
    }


def _state_from_context(model, context):
    tokens = tokenize(context)
    order = model["order"]
    if len(tokens) < order:
        raise ValueError(f"ต้องพิมพ์ข้อความอย่างน้อย {order} คำ")
    return " ".join(tokens[-order:])


def predict_next(model, context, top_k=5):
    """Return [(word, probability), ...] sorted by probability."""
    state = _state_from_context(model, context)
    counts = model["transitions"].get(state)
    if not counts:
        return []
    total = sum(counts.values())
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return [(w, c / total) for w, c in ranked[:top_k]]


def generate_text(model, context, length=15, seed=None):
    """Sample a continuation word by word from the chain."""
    rng = random.Random(seed)
    tokens = tokenize(context)
    order = model["order"]
    if len(tokens) < order:
        raise ValueError(f"ต้องพิมพ์ข้อความอย่างน้อย {order} คำ")
    out = list(tokens)
    for _ in range(length):
        state = " ".join(out[-order:])
        counts = model["transitions"].get(state)
        if not counts:
            break
        words, weights = zip(*counts.items())
        out.append(rng.choices(words, weights=weights, k=1)[0])
    return re.sub(r"\s+([.!?,])", r"\1", " ".join(out))


def transition_matrix(model, max_states=12):
    """Transition probability matrix for order-1 models.

    Uses the `max_states` most frequent states. Rows are 'from', columns are
    'to'. Probabilities come from the full model (not renormalised), so a row
    may sum to less than 1 when it leads to words outside the table.
    """
    if model["order"] != 1:
        raise ValueError("แสดง Transition Matrix ได้เฉพาะ order 1")
    freq = Counter()
    for state, nxt in model["transitions"].items():
        freq[state] += sum(nxt.values())
    states = [s for s, _ in freq.most_common(max_states)]
    matrix = []
    for s in states:
        counts = model["transitions"].get(s, {})
        total = sum(counts.values()) or 1
        matrix.append([counts.get(t, 0) / total for t in states])
    return {"states": states, "matrix": matrix}
