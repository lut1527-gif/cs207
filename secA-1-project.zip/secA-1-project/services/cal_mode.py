"""Mode calculation (supports multimodal data)."""
from collections import Counter


def frequency_table(data):
    """Return list of (value, count) sorted by value."""
    return sorted(Counter(data).items())


def calculate_mode(data):
    """Return a sorted list of modes.

    If every value appears exactly once (and there is more than one value),
    there is no mode and an empty list is returned.
    """
    if not data:
        raise ValueError("ไม่มีข้อมูลสำหรับคำนวณฐานนิยม")
    counts = Counter(data)
    top = max(counts.values())
    if top == 1 and len(counts) > 1:
        return []
    return sorted(v for v, c in counts.items() if c == top)
