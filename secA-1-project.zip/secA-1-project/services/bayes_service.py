"""Bayes' theorem: P(A|B) = P(B|A) * P(A) / P(B)."""


def _check_prob(name, value):
    if value is None or not (0.0 <= value <= 1.0):
        raise ValueError(f"{name} ต้องอยู่ระหว่าง 0 ถึง 1")


def evidence_from_complement(prior, likelihood, likelihood_not_a):
    """Law of total probability: P(B) = P(B|A)P(A) + P(B|not A)P(not A)."""
    return likelihood * prior + likelihood_not_a * (1 - prior)


def calculate_bayes(prior, likelihood, evidence=None, likelihood_not_a=None):
    """Return posterior and supporting numbers.

    Provide either `evidence` directly, or `likelihood_not_a` so that the
    evidence is derived with the law of total probability.
    """
    _check_prob("Prior P(A)", prior)
    _check_prob("Likelihood P(B|A)", likelihood)

    if evidence is None:
        _check_prob("P(B|ไม่ใช่ A)", likelihood_not_a)
        evidence = evidence_from_complement(prior, likelihood, likelihood_not_a)
    _check_prob("Evidence P(B)", evidence)

    if evidence == 0:
        raise ValueError("Evidence P(B) ต้องมากกว่า 0 (หารด้วยศูนย์ไม่ได้)")

    posterior = likelihood * prior / evidence
    if posterior > 1 + 1e-9:
        raise ValueError(
            "ค่าไม่สอดคล้องกัน: P(B) ต้องไม่น้อยกว่า P(B|A)·P(A) "
            f"(= {likelihood * prior:.4f})"
        )
    posterior = min(posterior, 1.0)

    return {
        "prior": prior,
        "likelihood": likelihood,
        "evidence": evidence,
        "posterior": posterior,
        "complement_posterior": 1 - posterior,
        "lift": posterior / prior if prior > 0 else float("nan"),
        "numerator": likelihood * prior,
    }


def posterior_curve(likelihood, likelihood_not_a, points=101):
    """Posterior as a function of the prior (for a sensitivity chart)."""
    _check_prob("Likelihood P(B|A)", likelihood)
    _check_prob("P(B|ไม่ใช่ A)", likelihood_not_a)
    priors, posts = [], []
    for i in range(points):
        p = i / (points - 1)
        ev = evidence_from_complement(p, likelihood, likelihood_not_a)
        priors.append(p)
        posts.append(likelihood * p / ev if ev > 0 else 0.0)
    return {"prior": priors, "posterior": posts}
