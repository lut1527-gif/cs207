"""Descriptive statistics: mean, median, mode, variance, SD."""
import math
import re

from services.cal_mode import calculate_mode, frequency_table


def parse_numbers(raw):
    """Parse text such as '-100, 0 10; 20' into a list of floats."""
    tokens = [t for t in re.split(r"[,\s;]+", (raw or "").strip()) if t]
    if not tokens:
        raise ValueError("กรุณากรอกตัวเลขอย่างน้อย 1 ค่า")
    numbers = []
    for token in tokens:
        try:
            value = float(token)
        except ValueError:
            raise ValueError(f"'{token}' ไม่ใช่ตัวเลข") from None
        if math.isnan(value) or math.isinf(value):
            raise ValueError(f"'{token}' ไม่ใช่ตัวเลขที่ใช้คำนวณได้")
        numbers.append(value)
    return numbers


def calculate_mean(data):
    return sum(data) / len(data)


def calculate_median(data):
    s = sorted(data)
    n = len(s)
    mid = n // 2
    return s[mid] if n % 2 else (s[mid - 1] + s[mid]) / 2


def calculate_variance(data, sample=False):
    n = len(data)
    if sample and n < 2:
        raise ValueError("Sample variance ต้องมีข้อมูลอย่างน้อย 2 ค่า")
    mean = calculate_mean(data)
    ss = sum((x - mean) ** 2 for x in data)
    return ss / (n - 1 if sample else n)


def calculate_sd(data, sample=False):
    return math.sqrt(calculate_variance(data, sample))


def summarize(data, sample=False):
    """Return every statistic in one dict for the UI."""
    if not data:
        raise ValueError("ไม่มีข้อมูล")
    return {
        "count": len(data),
        "sum": sum(data),
        "mean": calculate_mean(data),
        "median": calculate_median(data),
        "mode": calculate_mode(data),
        "variance": calculate_variance(data, sample),
        "sd": calculate_sd(data, sample),
        "min": min(data),
        "max": max(data),
        "range": max(data) - min(data),
        "sorted": sorted(data),
        "frequency": frequency_table(data),
        "sample": sample,
    }
