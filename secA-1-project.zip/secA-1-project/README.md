# secA-1-project

Streamlit Web App: สถิติ, Bayes, Markov Chain และ Sigmoid/Softmax Explorer

## วิธีรัน
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run main.py
```

## โครงสร้าง
- `main.py` : routing (st.navigation)
- `pages/` : UI เท่านั้น (รับค่า / แสดงผล)
- `services/` : logic การคำนวณทั้งหมด
- `data/` : raw_data.json, members.json, imgs/

## ก่อนส่งงาน
1. แก้ข้อมูลสมาชิกใน `data/members.json` (ชื่อ, รหัส, หน้าที่, ชื่อไฟล์รูป)
2. วางรูปจริงใน `data/imgs/` แทนรูป placeholder
3. เปลี่ยนชื่อโฟลเดอร์เป็น `sec{section}-{group}-project`
